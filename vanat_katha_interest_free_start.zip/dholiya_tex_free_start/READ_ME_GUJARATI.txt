VANAT KATHA - Interest Management System (Prototype)

આ ફાઇલ મફત ટેસ્ટિંગ માટે છે.

હાલના વર્ઝનની મર્યાદા:
- આ static prototype છે; ડેટા બ્રાઉઝરમાં localStorageમાં સેવ થાય છે.
- અલગ મોબાઇલ/કમ્પ્યુટર વચ્ચે ડેટા આપમેળે શેર થતો નથી.
- હજી વાસ્તવિક customer bills/payment data દાખલ ન કરો.
- Production ઉપયોગ પહેલાં secure login, cloud database, access control, server-side ₹500 approval rule અને backups જોડવા પડશે.

મફત પ્રારંભિક હોસ્ટિંગ માટે:
1. GitHub account બનાવો/લૉગિન કરો.
2. New public repository બનાવો, ઉદાહરણ: vanat-katha-interest.
3. આ ફોલ્ડરમાંથી index.html upload કરો.
4. Repository > Settings > Pages માં જઈ Deploy from a branch પસંદ કરો, Branch: main અને folder: /(root) પસંદ કરીને Save કરો.
5. થોડા સમય પછી GitHub Pages URL મળશે.

Custom domain interest.vanatkatha.com જોડતાં પહેલાં DNS records અને GitHub Pages domain settings બરાબર સેટ કરવાના રહેશે. હાલની vanatkatha.com વેબસાઇટના DNS records બદલો નહીં.

પછીના તબક્કામાં Supabase જેવી cloud database/auth service જોડીને અલગ login અને shared data તૈયાર કરવાના રહેશે. Free database plansમાં મર્યાદાઓ હોય છે; inactivity પર project pause થઈ શકે છે અને automatic backups ઉપલબ્ધ ન પણ હોય. તેથી પહેલા dummy dataથી test કરવું.
